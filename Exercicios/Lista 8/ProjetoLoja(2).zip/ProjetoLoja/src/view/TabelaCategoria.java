/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package view;

import beans.Categoria;
import dao.CategoriaDAO;
import java.util.List;
import javax.swing.table.DefaultTableModel;

/**
 * TELA DE RELATÓRIO (READ) DAS CATEGORIAS: lista as categorias em uma tabela com filtro por nome.
 */
public class TabelaCategoria extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(TabelaCategoria.class.getName());

    // O DAO é criado UMA vez só (campo da classe). Assim não abre uma conexão nova a cada letra digitada no filtro.
    private CategoriaDAO dao = new CategoriaDAO();

    public TabelaCategoria() {
        initComponents();
        preencheTabela();   // já abre a tela listando tudo (filtro vazio = LIKE '%%' = todos os registros)
    }

    // Enche a tabela com os dados do banco, aplicando o filtro digitado em txtNome.
    // É chamado quando a tela abre e a cada letra digitada (evento caretUpdate do campo).
    public void preencheTabela(){
        List<Categoria> listaCategorias = dao.getCategoriasNome(txtNome.getText());       // busca no banco já filtrado

        // pega o "modelo" da tabela (é ele que guarda as linhas) -> cast para DefaultTableModel
        DefaultTableModel modelo = (DefaultTableModel) tblCategorias.getModel();

        modelo.setNumRows(0);                                              // apaga todas as linhas antigas

        if (listaCategorias == null) {                                         // null = erro no banco
            return;
        }

        for (Categoria obj : listaCategorias) {                                   // para cada registro da lista...
            Object[] linha = new Object[]{                                 // ...monta uma linha (uma posição por coluna, na ordem da tabela)
                obj.getId(),                       // coluna 0: ID
                obj.getNome()                      // coluna 1: Nome
            };
            modelo.addRow(linha);                                          // adiciona a linha na tabela
        }
    }

    /**
     * Este método é gerado pelo NetBeans (JFrame Form) quando você arrasta componentes no modo Design.
     * NÃO precisa decorar: na prova, monte a tela arrastando os componentes e só escreva o código dos
     * métodos dos botões (os que têm "ActionPerformed" no nome), que ficam logo abaixo.
     * Obs.: se você mexer no modo Design, o NetBeans reescreve este bloco e apaga os comentários daqui.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        // ---- 1) cria os componentes ----
        jScrollPane1 = new javax.swing.JScrollPane();   // painel com barra de rolagem que contém a tabela
        tblCategorias = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        txtNome = new javax.swing.JTextField();         // campo do FILTRO
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE); // fecha só esta janela
        setTitle("Relatório de Categorias");

        // ---- 2) modelo da tabela: nomes das colunas e células NÃO editáveis (canEdit = false) ----
        tblCategorias.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nome"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tblCategorias);   // coloca a tabela dentro do painel de rolagem

        jLabel1.setText("Nome: ");

        // liga o evento "caretUpdate" (cursor/texto mudou) do campo ao método txtNomeCaretUpdate -> filtra enquanto digita
        txtNome.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                txtNomeCaretUpdate(evt);
            }
        });

        jLabel2.setText("Relatório");

        // ---- 3) posição dos componentes (GroupLayout) ----
        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(128, 128, 128))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(185, 185, 185)
                        .addComponent(jLabel2))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(30, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(23, 23, 23))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Evento do campo de filtro: roda a cada letra digitada/apagada. (No Design: botão direito no campo > Events > Caret > caretUpdate)
    private void txtNomeCaretUpdate(javax.swing.event.CaretEvent evt) {//GEN-FIRST:event_txtNomeCaretUpdate
        preencheTabela();   // refaz a tabela com o novo texto do filtro
    }//GEN-LAST:event_txtNomeCaretUpdate

    /**
     * main: só existe para poder rodar esta tela sozinha (Run File / Shift+F6). Pelo menu ela abre via new ...().setVisible(true).
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new TabelaCategoria().setVisible(true)); // cria a janela e mostra na tela
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblCategorias;
    private javax.swing.JTextField txtNome;
    // End of variables declaration//GEN-END:variables
}
