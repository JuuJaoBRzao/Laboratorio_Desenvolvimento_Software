/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package view;

/**
 * MENU PRINCIPAL do sistema: é a primeira tela. Cada item de menu abre uma das telas (JFrame) criadas.
 * Para abrir uma tela: crie o objeto e chame setVisible(true).
 */
public class MenuPrincipal extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(MenuPrincipal.class.getName());

    public MenuPrincipal() {
        initComponents();
    }

    /**
     * Este método é gerado pelo NetBeans (JFrame Form) quando você arrasta componentes no modo Design.
     * NÃO precisa decorar: na prova, monte a tela arrastando os componentes e só escreva o código dos
     * métodos dos botões (os que têm "ActionPerformed" no nome), que ficam logo abaixo.
     * Obs.: se você mexer no modo Design, o NetBeans reescreve este bloco e apaga os comentários daqui.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        // ---- 1) cria a barra de menu, os menus (JMenu) e os itens (JMenuItem) ----
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        menuSair = new javax.swing.JMenuItem();
        menuCadastro = new javax.swing.JMenu();
        menuCadProduto = new javax.swing.JMenuItem();
        menuEditarExcluirProduto = new javax.swing.JMenuItem();
        menuCadCategoria = new javax.swing.JMenuItem();
        menuEditarExcluirCategoria = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        menuTabelaProduto = new javax.swing.JMenuItem();
        menuTabelaCategoria = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE); // fechar o MENU encerra o programa
        setTitle("Sistema Loja");

        // ---- 2) monta cada menu: setText = nome; add = coloca o item dentro do menu; addActionListener = ação do clique ----
        jMenu1.setText("Arquivo");

        menuSair.setText("Sair");
        menuSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuSairActionPerformed(evt);
            }
        });
        jMenu1.add(menuSair);

        jMenuBar1.add(jMenu1);   // coloca o menu "Arquivo" na barra

        menuCadastro.setText("Cadastro");

        menuCadProduto.setText("Cadastro Produtos");
        menuCadProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuCadProdutoActionPerformed(evt);
            }
        });
        menuCadastro.add(menuCadProduto);

        menuEditarExcluirProduto.setText("Editar e Excluir Produtos");
        menuEditarExcluirProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuEditarExcluirProdutoActionPerformed(evt);
            }
        });
        menuCadastro.add(menuEditarExcluirProduto);

        menuCadCategoria.setText("Cadastro Categorias");
        menuCadCategoria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuCadCategoriaActionPerformed(evt);
            }
        });
        menuCadastro.add(menuCadCategoria);

        menuEditarExcluirCategoria.setText("Editar e Excluir Categorias");
        menuEditarExcluirCategoria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuEditarExcluirCategoriaActionPerformed(evt);
            }
        });
        menuCadastro.add(menuEditarExcluirCategoria);

        jMenuBar1.add(menuCadastro);

        jMenu3.setText("Relatórios");

        menuTabelaProduto.setText("Tabela Produtos");
        menuTabelaProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuTabelaProdutoActionPerformed(evt);
            }
        });
        jMenu3.add(menuTabelaProduto);

        menuTabelaCategoria.setText("Tabela Categorias");
        menuTabelaCategoria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuTabelaCategoriaActionPerformed(evt);
            }
        });
        jMenu3.add(menuTabelaCategoria);

        jMenuBar1.add(jMenu3);

        setJMenuBar(jMenuBar1);   // define a barra de menu da janela

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 277, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Cada método abaixo abre uma tela: new NomeDaTela() cria a janela e setVisible(true) mostra.
    private void menuCadProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuCadProdutoActionPerformed
        FormProdutos cadProduto = new FormProdutos();
        cadProduto.setVisible(true);
    }//GEN-LAST:event_menuCadProdutoActionPerformed

    private void menuEditarExcluirProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuEditarExcluirProdutoActionPerformed
        EditarExcluirProduto editarExcluirProduto = new EditarExcluirProduto();
        editarExcluirProduto.setVisible(true);
    }//GEN-LAST:event_menuEditarExcluirProdutoActionPerformed

    private void menuCadCategoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuCadCategoriaActionPerformed
        FormCategoria cadCategoria = new FormCategoria();
        cadCategoria.setVisible(true);
    }//GEN-LAST:event_menuCadCategoriaActionPerformed

    private void menuEditarExcluirCategoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuEditarExcluirCategoriaActionPerformed
        EditarExcluirCategoria editarExcluirCategoria = new EditarExcluirCategoria();
        editarExcluirCategoria.setVisible(true);
    }//GEN-LAST:event_menuEditarExcluirCategoriaActionPerformed

    private void menuTabelaProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuTabelaProdutoActionPerformed
        TabelaProdutos tblProdutos = new TabelaProdutos();
        tblProdutos.setVisible(true);
    }//GEN-LAST:event_menuTabelaProdutoActionPerformed

    private void menuTabelaCategoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuTabelaCategoriaActionPerformed
        TabelaCategoria tblCategorias = new TabelaCategoria();
        tblCategorias.setVisible(true);
    }//GEN-LAST:event_menuTabelaCategoriaActionPerformed

    // Item Arquivo > Sair: encerra o programa inteiro
    private void menuSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuSairActionPerformed
        System.exit(0);
    }//GEN-LAST:event_menuSairActionPerformed

    /**
     * main: só existe para poder rodar esta tela sozinha (Run File / Shift+F6). Pelo menu ela abre via new ...().setVisible(true).
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new MenuPrincipal().setVisible(true)); // cria a janela e mostra na tela
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem menuCadCategoria;
    private javax.swing.JMenuItem menuCadProduto;
    private javax.swing.JMenu menuCadastro;
    private javax.swing.JMenuItem menuEditarExcluirCategoria;
    private javax.swing.JMenuItem menuEditarExcluirProduto;
    private javax.swing.JMenuItem menuSair;
    private javax.swing.JMenuItem menuTabelaCategoria;
    private javax.swing.JMenuItem menuTabelaProduto;
    // End of variables declaration//GEN-END:variables
}
