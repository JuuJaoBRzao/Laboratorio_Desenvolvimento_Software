/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package view;

import beans.Categoria;
import beans.Produtos;
import dao.CategoriaDAO;
import dao.ProdutoDAO;
import java.util.List;
import javax.swing.JOptionPane;   // caixinha de mensagem (showMessageDialog)

/**
 * TELA DE CADASTRO DE PRODUTOS (CREATE / INSERT).
 * Fluxo: o usuário preenche nome, preço, quantidade e escolhe a categoria no combo -> clica em Salvar
 * -> o botão monta um objeto Produtos -> chama ProdutoDAO.inserir().
 */
public class FormProdutos extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(FormProdutos.class.getName());

    public FormProdutos() {
        initComponents();       // monta a tela (código gerado pelo NetBeans)
        carregarCategorias();   // enche o combo com as categorias cadastradas no banco
    }

    // Enche o combo de categorias com o que está no banco (é isso que "lista as categorias cadastradas").
    // O combo é JComboBox<Categoria>: guarda objetos Categoria e mostra o toString() (o nome).
    // >>> No NetBeans: botão direito no combo > Properties > Code > Type Parameters = <Categoria>
    private void carregarCategorias() {
        cmbCategoria.removeAllItems();                      // limpa o combo antes de encher
        CategoriaDAO cdao = new CategoriaDAO();
        List<Categoria> lista = cdao.getCategorias();       // busca as categorias no banco
        if (lista == null) {                                // null = deu erro no banco (ex.: MySQL desligado)
            return;
        }
        for (Categoria c : lista) {
            cmbCategoria.addItem(c);                        // addItem coloca o objeto no combo
        }
        cmbCategoria.setSelectedIndex(-1);                  // -1 = nenhum item selecionado (combo em branco)
    }

    // Limpa a tela depois de salvar
    private void limparFormulario() {
        txtNome.setText("");
        txtPreco.setText("");
        txtQuantidade.setText("");
        cmbCategoria.setSelectedIndex(-1);
        txtNome.requestFocus();                             // devolve o cursor para o campo Nome
    }

    /**
     * Este método é gerado pelo NetBeans (JFrame Form) quando você arrasta componentes no modo Design.
     * NÃO precisa decorar: na prova, monte a tela arrastando os componentes e só escreva o código dos
     * métodos dos botões (os que têm "ActionPerformed" no nome), que ficam logo abaixo.
     * Obs.: se você mexer no modo Design, o NetBeans reescreve este bloco e apaga os comentários daqui.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        // ---- 1) cria cada componente da tela (os que você arrasta da Palette no modo Design) ----
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtNome = new javax.swing.JTextField();
        txtPreco = new javax.swing.JTextField();
        txtQuantidade = new javax.swing.JTextField();
        cmbCategoria = new javax.swing.JComboBox<>();
        btnSalvar = new javax.swing.JButton();

        // ---- 2) propriedades da janela ----
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE); // o que acontece ao clicar no X

        // ---- 3) propriedades de cada componente (as que você muda na aba Properties) ----
        // textos dos rótulos (JLabel)
        jLabel1.setText("Nome:");
        jLabel2.setText("Preço:");
        jLabel3.setText("Quantidade:");
        jLabel4.setText("Categoria:");
        btnSalvar.setText("Salvar"); // texto do botão
        btnSalvar.addActionListener(new java.awt.event.ActionListener() { // liga o CLIQUE do botão ao método abaixo
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarActionPerformed(evt);
            }
        });

        // ---- 4) posição dos componentes na janela (GroupLayout, gerado pelo editor visual) ----
        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtPreco, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtQuantidade, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(cmbCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20)
                        .addComponent(btnSalvar)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtPreco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtQuantidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(cmbCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSalvar))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack(); // ajusta o tamanho da janela ao conteúdo
    }// </editor-fold>//GEN-END:initComponents

    // Método do botão Salvar (no Design: duplo clique no botão cria este método).
    private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvarActionPerformed
        // 1) VALIDAÇÃO: nome vazio ou nenhuma categoria escolhida -> avisa e sai (return)
        if (txtNome.getText().isEmpty() || cmbCategoria.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Preencha todos os campos!");
            return;
        }
        try {
            // 2) Monta o objeto com os dados da tela
            Produtos p = new Produtos();
            p.setNome(txtNome.getText());                                          // texto do campo -> String
            p.setPreco(Double.parseDouble(txtPreco.getText().replace(",", ".")));  // texto -> double (troca vírgula por ponto: 10,50 -> 10.50)
            p.setQuantidade(Integer.parseInt(txtQuantidade.getText()));            // texto -> int (se não for número cai no catch)
            // getSelectedItem() devolve Object; o cast (Categoria) devolve o objeto da categoria escolhida no combo
            p.setCategoria((Categoria) cmbCategoria.getSelectedItem());

            // 3) Salva no banco pelo DAO
            ProdutoDAO dao = new ProdutoDAO();
            if (dao.inserir(p)) {                                                  // inserir devolve true/false
                JOptionPane.showMessageDialog(null, "Salvamento efetuado com sucesso", "Mensagem", JOptionPane.INFORMATION_MESSAGE);
                limparFormulario();
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao cadastrar!");
            }
        } catch (NumberFormatException e) {
            // parseDouble/parseInt lançam NumberFormatException quando o texto não é número
            JOptionPane.showMessageDialog(this, "Preço e quantidade precisam ser números!");
        }
    }//GEN-LAST:event_btnSalvarActionPerformed

    /**
     * main: só existe para poder rodar esta tela sozinha (Run File / Shift+F6). Pelo menu ela abre via new ...().setVisible(true).
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new FormProdutos().setVisible(true)); // cria a janela e mostra na tela
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSalvar;
    private javax.swing.JComboBox<Categoria> cmbCategoria;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JTextField txtNome;
    private javax.swing.JTextField txtPreco;
    private javax.swing.JTextField txtQuantidade;
    // End of variables declaration//GEN-END:variables
}
