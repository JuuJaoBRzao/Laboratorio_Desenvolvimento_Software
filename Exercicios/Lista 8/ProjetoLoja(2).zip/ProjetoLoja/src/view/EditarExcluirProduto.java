/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package view;

import beans.Categoria;
import beans.Produtos;
import dao.CategoriaDAO;
import dao.ProdutoDAO;
import java.util.List;
import javax.swing.JOptionPane;

/**
 * TELA DE CONSULTAR / ATUALIZAR / EXCLUIR PRODUTO (READ por ID + UPDATE + DELETE).
 * Fluxo: digita o ID (txtID) e clica em Consultar -> os campos são preenchidos.
 *   - Atualizar: salva as mudanças (inclusive a TROCA DE CATEGORIA no combo).
 *   - Excluir: apaga o produto (pede confirmação).
 * txtIDblock (desabilitado) guarda o ID do produto consultado; Atualizar e Excluir usam ele, não o txtID digitado.
 */
public class EditarExcluirProduto extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(EditarExcluirProduto.class.getName());

    public EditarExcluirProduto() {
        initComponents();
        carregarCategorias();   // o combo precisa estar cheio antes de consultar (para poder selecionar a categoria do produto)
    }

    // Enche o combo com as categorias do banco (igual ao FormProdutos)
    private void carregarCategorias() {
        cmbCategoria.removeAllItems();
        CategoriaDAO cdao = new CategoriaDAO();
        List<Categoria> lista = cdao.getCategorias();
        if (lista == null) {
            return;
        }
        for (Categoria c : lista) {
            cmbCategoria.addItem(c);
        }
        cmbCategoria.setSelectedIndex(-1);
    }

    // Seleciona no combo a categoria que tem o id informado.
    // Precisa deste for porque setSelectedItem(objeto) não acha o item (os objetos são diferentes), então comparamos pelo ID.
    private void selecionarCategoria(int idCategoria) {
        for (int i = 0; i < cmbCategoria.getItemCount(); i++) {       // percorre todos os itens do combo
            if (cmbCategoria.getItemAt(i).getId() == idCategoria) {   // getItemAt(i) devolve a Categoria da posição i
                cmbCategoria.setSelectedIndex(i);                     // seleciona o item encontrado
                return;
            }
        }
        cmbCategoria.setSelectedIndex(-1);                            // não achou: deixa em branco
    }

    public void limparFormulario() {
        txtID.setText("");
        txtIDblock.setText("");
        txtNome.setText("");
        txtPreco.setText("");
        txtQuantidade.setText("");
        cmbCategoria.setSelectedIndex(-1);
    }

    /**
     * Este método é gerado pelo NetBeans (JFrame Form) quando você arrasta componentes no modo Design.
     * NÃO precisa decorar: na prova, monte a tela arrastando os componentes e só escreva o código dos
     * métodos dos botões (os que têm "ActionPerformed" no nome), que ficam logo abaixo.
     * Obs.: se você mexer no modo Design, o NetBeans reescreve este bloco e apaga os comentários daqui.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        // ---- 1) cria cada componente da tela (os que você arrasta da Palette no modo Design) ----
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtID = new javax.swing.JTextField();
        txtIDblock = new javax.swing.JTextField();
        txtNome = new javax.swing.JTextField();
        txtPreco = new javax.swing.JTextField();
        txtQuantidade = new javax.swing.JTextField();
        cmbCategoria = new javax.swing.JComboBox<>();
        btnConsultar = new javax.swing.JButton();
        btnAtualizar = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();

        // ---- 2) propriedades da janela ----
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE); // o que acontece ao clicar no X

        // ---- 3) propriedades de cada componente (as que você muda na aba Properties) ----
        // textos dos rótulos (JLabel)
        jLabel1.setText("ID");
        jLabel2.setText("ID");
        jLabel3.setText("Nome");
        jLabel4.setText("Preço");
        jLabel5.setText("Quantidade");
        jLabel6.setText("Categoria");
        // campo bloqueado: só mostra o ID do registro consultado, o usuário não consegue digitar
        txtIDblock.setEnabled(false);
        btnConsultar.setText("Consultar"); // texto do botão
        btnConsultar.addActionListener(new java.awt.event.ActionListener() { // liga o CLIQUE do botão ao método abaixo
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultarActionPerformed(evt);
            }
        });
        btnAtualizar.setText("Atualizar"); // texto do botão
        btnAtualizar.addActionListener(new java.awt.event.ActionListener() { // liga o CLIQUE do botão ao método abaixo
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAtualizarActionPerformed(evt);
            }
        });
        btnExcluir.setText("Excluir"); // texto do botão
        btnExcluir.addActionListener(new java.awt.event.ActionListener() { // liga o CLIQUE do botão ao método abaixo
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirActionPerformed(evt);
            }
        });

        // ---- 4) posição dos componentes na janela (GroupLayout, gerado pelo editor visual) ----
        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(txtID, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20)
                        .addComponent(btnConsultar))
                    .addComponent(txtIDblock, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtPreco, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtQuantidade, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnAtualizar)
                        .addGap(20, 20, 20)
                        .addComponent(btnExcluir)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnConsultar))
                .addGap(15, 15, 15)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtIDblock, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtPreco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtQuantidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(cmbCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAtualizar)
                    .addComponent(btnExcluir))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack(); // ajusta o tamanho da janela ao conteúdo
    }// </editor-fold>//GEN-END:initComponents

    // CONSULTAR: busca o produto pelo ID digitado e preenche a tela
    private void btnConsultarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultarActionPerformed
        try {
            int idProduto = Integer.parseInt(txtID.getText());        // texto -> int (NumberFormatException se não for número)
            ProdutoDAO dao = new ProdutoDAO();

            Produtos p = dao.getProdutosPorID(idProduto);             // busca no banco (null se não existir)
            if (p == null) {
                limparFormulario();
                JOptionPane.showMessageDialog(this, "Produto não encontrado");
            } else {
                txtIDblock.setText(p.getId() + "");                   // "+ """ converte número em texto
                txtNome.setText(p.getNome());
                txtPreco.setText(p.getPreco() + "");
                txtQuantidade.setText(p.getQuantidade() + "");
                selecionarCategoria(p.getCategoria().getId());        // marca no combo a categoria atual do produto
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "O ID precisa ser um número!");
        }
    }//GEN-LAST:event_btnConsultarActionPerformed

    // ATUALIZAR: grava as alterações (UPDATE). A categoria nova é a que estiver selecionada no combo.
    private void btnAtualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAtualizarActionPerformed
        if (txtIDblock.getText().isEmpty()) {                         // só dá para atualizar depois de consultar
            JOptionPane.showMessageDialog(this, "Consulte um registro primeiro!");
            return;
        }
        if (txtNome.getText().isEmpty() || cmbCategoria.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Preencha todos os campos!");
            return;
        }
        try {
            Produtos p = new Produtos();
            p.setId(Integer.parseInt(txtIDblock.getText()));          // WHERE do UPDATE: qual produto alterar
            p.setNome(txtNome.getText());
            p.setPreco(Double.parseDouble(txtPreco.getText().replace(",", ".")));
            p.setQuantidade(Integer.parseInt(txtQuantidade.getText()));
            p.setCategoria((Categoria) cmbCategoria.getSelectedItem());   // TROCA DE CATEGORIA: pega o item escolhido no combo

            ProdutoDAO dao = new ProdutoDAO();
            if (dao.editar(p)) {
                JOptionPane.showMessageDialog(null, "Atualização efetuada com sucesso", "Mensagem", JOptionPane.INFORMATION_MESSAGE);
                limparFormulario();
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao atualizar!");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Preço e quantidade precisam ser números!");
        }
    }//GEN-LAST:event_btnAtualizarActionPerformed

    // EXCLUIR: pede confirmação e apaga (DELETE)
    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirActionPerformed
        if (txtIDblock.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Consulte um registro primeiro!");
            return;
        }
        // showConfirmDialog devolve qual botão foi clicado (YES_OPTION = "Sim")
        int resposta = JOptionPane.showConfirmDialog(null, "Deseja realmente excluir?", "Exclusão", JOptionPane.YES_NO_OPTION);
        if (resposta == JOptionPane.YES_OPTION) {
            ProdutoDAO dao = new ProdutoDAO();
            if (dao.excluir(Integer.parseInt(txtIDblock.getText()))) {
                limparFormulario();
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao excluir!");
            }
        }
    }//GEN-LAST:event_btnExcluirActionPerformed

    /**
     * main: só existe para poder rodar esta tela sozinha (Run File / Shift+F6). Pelo menu ela abre via new ...().setVisible(true).
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new EditarExcluirProduto().setVisible(true)); // cria a janela e mostra na tela
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAtualizar;
    private javax.swing.JButton btnConsultar;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JComboBox<Categoria> cmbCategoria;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JTextField txtID;
    private javax.swing.JTextField txtIDblock;
    private javax.swing.JTextField txtNome;
    private javax.swing.JTextField txtPreco;
    private javax.swing.JTextField txtQuantidade;
    // End of variables declaration//GEN-END:variables
}
