/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package view;

import beans.Categoria;
import dao.CategoriaDAO;
import javax.swing.JOptionPane;

/**
 * TELA DE CADASTRO DE CATEGORIAS (CREATE / INSERT).
 */
public class FormCategoria extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(FormCategoria.class.getName());

    public FormCategoria() {
        initComponents();
    }

    private void limparFormulario() {
        txtNome.setText("");
        txtNome.requestFocus();
    }

    /**
     * Este método é gerado pelo NetBeans (JFrame Form) quando você arrasta componentes no modo Design.
     * NÃO precisa decorar: na prova, monte a tela arrastando os componentes e só escreva o código dos
     * métodos dos botões (os que têm "ActionPerformed" no nome), que ficam logo abaixo.
     * Obs.: se você mexer no modo Design, o NetBeans reescreve este bloco e apaga os comentários daqui.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        // ---- 1) cria cada componente da tela (os que você arrasta da Palette no modo Design) ----
        jLabel1 = new javax.swing.JLabel();
        txtNome = new javax.swing.JTextField();
        btnSalvar = new javax.swing.JButton();

        // ---- 2) propriedades da janela ----
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE); // o que acontece ao clicar no X

        // ---- 3) propriedades de cada componente (as que você muda na aba Properties) ----
        // textos dos rótulos (JLabel)
        jLabel1.setText("Nome:");
        btnSalvar.setText("Salvar"); // texto do botão
        btnSalvar.addActionListener(new java.awt.event.ActionListener() { // liga o CLIQUE do botão ao método abaixo
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarActionPerformed(evt);
            }
        });

        // ---- 4) posição dos componentes na janela (GroupLayout, gerado pelo editor visual) ----
        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20)
                        .addComponent(btnSalvar)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSalvar))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack(); // ajusta o tamanho da janela ao conteúdo
    }// </editor-fold>//GEN-END:initComponents

    // Botão Salvar
    private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvarActionPerformed
        if (txtNome.getText().isEmpty()) {                              // validação: nome é obrigatório
            JOptionPane.showMessageDialog(this, "Preencha o nome!");
            return;
        }
        Categoria c = new Categoria();                                  // objeto com os dados da tela
        c.setNome(txtNome.getText());

        CategoriaDAO dao = new CategoriaDAO();
        if (dao.inserir(c)) {                                           // true = salvou
            JOptionPane.showMessageDialog(null, "Salvamento efetuado com sucesso", "Mensagem", JOptionPane.INFORMATION_MESSAGE);
            limparFormulario();
        } else {
            JOptionPane.showMessageDialog(this, "Erro ao cadastrar!");
        }
    }//GEN-LAST:event_btnSalvarActionPerformed

    /**
     * main: só existe para poder rodar esta tela sozinha (Run File / Shift+F6). Pelo menu ela abre via new ...().setVisible(true).
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new FormCategoria().setVisible(true)); // cria a janela e mostra na tela
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSalvar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JTextField txtNome;
    // End of variables declaration//GEN-END:variables
}
