/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package view;

import beans.Categoria;
import dao.CategoriaDAO;
import javax.swing.JOptionPane;

/**
 * TELA DE CONSULTAR / EDITAR / EXCLUIR CATEGORIA (mesma ideia da tela de produtos, só que com um campo).
 */
public class EditarExcluirCategoria extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(EditarExcluirCategoria.class.getName());

    public EditarExcluirCategoria() {
        initComponents();
    }

    public void limparFormulario() {
        txtID.setText("");
        txtIDblock.setText("");
        txtNome.setText("");
    }

    /**
     * Este método é gerado pelo NetBeans (JFrame Form) quando você arrasta componentes no modo Design.
     * NÃO precisa decorar: na prova, monte a tela arrastando os componentes e só escreva o código dos
     * métodos dos botões (os que têm "ActionPerformed" no nome), que ficam logo abaixo.
     * Obs.: se você mexer no modo Design, o NetBeans reescreve este bloco e apaga os comentários daqui.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        // ---- 1) cria cada componente da tela (os que você arrasta da Palette no modo Design) ----
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtID = new javax.swing.JTextField();
        txtIDblock = new javax.swing.JTextField();
        txtNome = new javax.swing.JTextField();
        btnConsultar = new javax.swing.JButton();
        btnAtualizar = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();

        // ---- 2) propriedades da janela ----
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE); // o que acontece ao clicar no X

        // ---- 3) propriedades de cada componente (as que você muda na aba Properties) ----
        // textos dos rótulos (JLabel)
        jLabel1.setText("ID");
        jLabel2.setText("ID");
        jLabel3.setText("Nome");
        // campo bloqueado: só mostra o ID do registro consultado, o usuário não consegue digitar
        txtIDblock.setEnabled(false);
        btnConsultar.setText("Consultar"); // texto do botão
        btnConsultar.addActionListener(new java.awt.event.ActionListener() { // liga o CLIQUE do botão ao método abaixo
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultarActionPerformed(evt);
            }
        });
        btnAtualizar.setText("Atualizar"); // texto do botão
        btnAtualizar.addActionListener(new java.awt.event.ActionListener() { // liga o CLIQUE do botão ao método abaixo
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAtualizarActionPerformed(evt);
            }
        });
        btnExcluir.setText("Excluir"); // texto do botão
        btnExcluir.addActionListener(new java.awt.event.ActionListener() { // liga o CLIQUE do botão ao método abaixo
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirActionPerformed(evt);
            }
        });

        // ---- 4) posição dos componentes na janela (GroupLayout, gerado pelo editor visual) ----
        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(txtID, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20)
                        .addComponent(btnConsultar))
                    .addComponent(txtIDblock, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnAtualizar)
                        .addGap(20, 20, 20)
                        .addComponent(btnExcluir)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnConsultar))
                .addGap(15, 15, 15)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtIDblock, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAtualizar)
                    .addComponent(btnExcluir))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack(); // ajusta o tamanho da janela ao conteúdo
    }// </editor-fold>//GEN-END:initComponents

    // CONSULTAR por ID
    private void btnConsultarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultarActionPerformed
        try {
            int idCategoria = Integer.parseInt(txtID.getText());
            CategoriaDAO dao = new CategoriaDAO();

            Categoria c = dao.getCategoria(idCategoria);               // null se não existir
            if (c == null) {
                limparFormulario();
                JOptionPane.showMessageDialog(this, "Categoria não encontrada");
            } else {
                txtIDblock.setText(c.getId() + "");
                txtNome.setText(c.getNome());
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "O ID precisa ser um número!");
        }
    }//GEN-LAST:event_btnConsultarActionPerformed

    // ATUALIZAR (UPDATE)
    private void btnAtualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAtualizarActionPerformed
        if (txtIDblock.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Consulte um registro primeiro!");
            return;
        }
        if (txtNome.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Preencha o nome!");
            return;
        }
        Categoria c = new Categoria();
        c.setId(Integer.parseInt(txtIDblock.getText()));               // id do registro consultado
        c.setNome(txtNome.getText());

        CategoriaDAO dao = new CategoriaDAO();
        if (dao.editar(c)) {
            JOptionPane.showMessageDialog(null, "Atualização efetuada com sucesso", "Mensagem", JOptionPane.INFORMATION_MESSAGE);
            limparFormulario();
        } else {
            JOptionPane.showMessageDialog(this, "Erro ao atualizar!");
        }
    }//GEN-LAST:event_btnAtualizarActionPerformed

    // EXCLUIR (DELETE) com confirmação. Falha se a categoria tiver produtos (chave estrangeira).
    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirActionPerformed
        if (txtIDblock.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Consulte um registro primeiro!");
            return;
        }
        int resposta = JOptionPane.showConfirmDialog(null, "Deseja realmente excluir?", "Exclusão", JOptionPane.YES_NO_OPTION);
        if (resposta == JOptionPane.YES_OPTION) {
            CategoriaDAO dao = new CategoriaDAO();
            if (dao.excluir(Integer.parseInt(txtIDblock.getText()))) {
                limparFormulario();
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao excluir! Verifique se existem produtos nesta categoria.");
            }
        }
    }//GEN-LAST:event_btnExcluirActionPerformed

    /**
     * main: só existe para poder rodar esta tela sozinha (Run File / Shift+F6). Pelo menu ela abre via new ...().setVisible(true).
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new EditarExcluirCategoria().setVisible(true)); // cria a janela e mostra na tela
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAtualizar;
    private javax.swing.JButton btnConsultar;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JTextField txtID;
    private javax.swing.JTextField txtIDblock;
    private javax.swing.JTextField txtNome;
    // End of variables declaration//GEN-END:variables
}
