package beans;

/**
 * BEAN (modelo) da tabela Produtos.
 * A chave estrangeira (fk_id_categoria) vira um atributo do tipo Categoria (objeto),
 * assim o produto "carrega" a categoria inteira (id + nome).
 */
public class Produtos {
    private int id;                 // coluna id_produto
    private String nome;            // coluna nome
    private double preco;           // coluna preco (DECIMAL no banco -> double no Java)
    private int quantidade;         // coluna quantidade
    private Categoria categoria;    // coluna fk_id_categoria (chave estrangeira) -> objeto Categoria

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }
}
