package beans;

/**
 * BEAN (modelo) da tabela Categorias.
 * Bean = classe que só GUARDA dados: atributos privados + getters/setters.
 * Regra: um atributo para cada coluna da tabela (id_categoria -> id, nome -> nome).
 */
public class Categoria {
    private int id;        // coluna id_categoria
    private String nome;   // coluna nome

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    // toString = o texto que o JComboBox<Categoria> mostra para cada item.
    // Sem este método o combo mostraria algo como "beans.Categoria@1a2b3c".
    @Override
    public String toString() {
        return nome;
    }
}
