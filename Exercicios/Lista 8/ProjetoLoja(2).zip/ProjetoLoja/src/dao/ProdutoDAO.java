package dao;

import beans.Categoria;
import beans.Produtos;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO da tabela Produtos. Contém o CRUD (inserir, consultar, editar, excluir) e a busca.
 * Como Produtos tem chave estrangeira, os SELECTs usam JOIN com Categorias para trazer também o NOME da categoria.
 * Cada método tem o seu SQL completo e monta o objeto na própria consulta (sem métodos auxiliares).
 */
public class ProdutoDAO {

    private Conexao conexao;
    private Connection conn;

    // Construtor: abre a conexão (o erro do projeto original era não criar a conexão aqui, então conn ficava null).
    public ProdutoDAO() {
        this.conexao = new Conexao();             // cria o objeto de conexão
        this.conn = this.conexao.getConexao();    // abre a conexão e guarda em conn
    }

    // LISTAR TODOS os produtos
    public List<Produtos> getProdutos(){
        // JOIN liga Produtos (p) com Categorias (c) pela chave estrangeira, para trazer o NOME da categoria.
        // "c.nome AS nome_categoria" = apelido, porque p.nome e c.nome têm o mesmo nome de coluna.
        // LEFT JOIN = traz o produto mesmo que ele não tenha categoria.
        String sql = "SELECT p.id_produto, p.nome, p.preco, p.quantidade, p.fk_id_categoria, c.nome AS nome_categoria "
                   + "FROM Produtos p LEFT JOIN Categorias c ON p.fk_id_categoria = c.id_categoria "
                   + "ORDER BY p.id_produto";
        try{
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);

            ResultSet rs = stmt.executeQuery();                    // executa o SELECT
            List<Produtos> listaProdutos = new ArrayList<>();      // lista que vai guardar o resultado
            while (rs.next()){                                     // uma volta do while = uma linha da tabela
                Produtos p = new Produtos();
                p.setId(rs.getInt("id_produto"));                  // pega cada coluna pelo NOME
                p.setNome(rs.getString("nome"));
                p.setPreco(rs.getDouble("preco"));                 // getDouble para coluna DECIMAL
                p.setQuantidade(rs.getInt("quantidade"));

                Categoria c = new Categoria();                     // a categoria do produto é outro objeto
                c.setId(rs.getInt("fk_id_categoria"));             // chave estrangeira
                c.setNome(rs.getString("nome_categoria"));         // nome que veio do JOIN (usa o apelido)
                p.setCategoria(c);                                 // coloca a categoria dentro do produto

                listaProdutos.add(p);                              // adiciona o produto na lista
            }
            return listaProdutos;
        } catch (SQLException ex) {
            System.out.println("Erro ao consultar todos os produtos: " + ex.getMessage());
            return null;                                           // as telas conferem "if (lista == null)"
        }
    }

    // CONSULTAR POR ID -> devolve UM produto, ou null se não existir
    public Produtos getProdutosPorID(int id) {
        String sql = "SELECT p.id_produto, p.nome, p.preco, p.quantidade, p.fk_id_categoria, c.nome AS nome_categoria "
                   + "FROM Produtos p LEFT JOIN Categorias c ON p.fk_id_categoria = c.id_categoria "
                   + "WHERE p.id_produto = ?";
        try{
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stmt.setInt(1, id);                                    // coloca o id no "?"

            ResultSet rs = stmt.executeQuery();
            if (rs.first()) {                                      // rs.first() = true se achou a primeira linha
                Produtos p = new Produtos();
                p.setId(rs.getInt("id_produto"));
                p.setNome(rs.getString("nome"));
                p.setPreco(rs.getDouble("preco"));
                p.setQuantidade(rs.getInt("quantidade"));

                Categoria c = new Categoria();
                c.setId(rs.getInt("fk_id_categoria"));
                c.setNome(rs.getString("nome_categoria"));
                p.setCategoria(c);

                return p;
            }
            return null;                                           // não achou nenhum produto com esse id
        } catch (SQLException ex) {
            System.out.println("Erro ao consultar produto: " + ex.getMessage());
            return null;
        }
    }

    // BUSCA por NOME do produto OU NOME da categoria (o "OR" é o que o exercício pede)
    public List<Produtos> getProdutosBusca(String busca){
        String sql = "SELECT p.id_produto, p.nome, p.preco, p.quantidade, p.fk_id_categoria, c.nome AS nome_categoria "
                   + "FROM Produtos p LEFT JOIN Categorias c ON p.fk_id_categoria = c.id_categoria "
                   + "WHERE p.nome LIKE ? OR c.nome LIKE ? "
                   + "ORDER BY p.id_produto";
        try{
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stmt.setString(1, "%" + busca + "%");                  // 1º "?" -> nome do produto contém o texto (% = qualquer coisa)
            stmt.setString(2, "%" + busca + "%");                  // 2º "?" -> nome da categoria contém o texto

            ResultSet rs = stmt.executeQuery();
            List<Produtos> listaProdutos = new ArrayList<>();
            while (rs.next()){
                Produtos p = new Produtos();
                p.setId(rs.getInt("id_produto"));
                p.setNome(rs.getString("nome"));
                p.setPreco(rs.getDouble("preco"));
                p.setQuantidade(rs.getInt("quantidade"));

                Categoria c = new Categoria();
                c.setId(rs.getInt("fk_id_categoria"));
                c.setNome(rs.getString("nome_categoria"));
                p.setCategoria(c);

                listaProdutos.add(p);
            }
            return listaProdutos;
        } catch (SQLException ex) {
            System.out.println("Erro ao buscar produtos: " + ex.getMessage());
            return null;
        }
    }

    // INSERT -> a categoria entra pela chave estrangeira (fk_id_categoria). Devolve true se salvou, false se deu erro.
    public boolean inserir(Produtos produtos) {
        try {
            String sql = "INSERT INTO Produtos (nome, preco, quantidade, fk_id_categoria) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, produtos.getNome());                  // texto   -> setString
            stmt.setDouble(2, produtos.getPreco());                 // decimal -> setDouble
            stmt.setInt(3, produtos.getQuantidade());               // inteiro -> setInt
            stmt.setInt(4, produtos.getCategoria().getId());        // só o ID da categoria vai para o banco

            stmt.execute();                                         // execute() é usado em INSERT/UPDATE/DELETE
            return true;
        } catch (SQLException ex) {
            System.out.println("Erro ao inserir produto: " + ex.getMessage());
            return false;
        }
    }

    // UPDATE -> também altera a categoria (é assim que a categoria muda na edição)
    public boolean editar(Produtos produtos){
        try {
            String sql = "UPDATE Produtos SET nome = ?, preco = ?, quantidade = ?, fk_id_categoria = ? WHERE id_produto = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, produtos.getNome());
            stmt.setDouble(2, produtos.getPreco());
            stmt.setInt(3, produtos.getQuantidade());
            stmt.setInt(4, produtos.getCategoria().getId());        // nova categoria escolhida no combo
            stmt.setInt(5, produtos.getId());                       // WHERE: qual produto será alterado (a ordem dos números segue os "?")

            stmt.execute();
            return true;
        } catch (SQLException ex) {
            System.out.println("Erro ao atualizar produto: " + ex.getMessage());
            return false;
        }
    }

    // DELETE
    public boolean excluir(int id) {
        try {
            String sql = "DELETE FROM Produtos WHERE id_produto = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);

            stmt.execute();
            return true;
        } catch (SQLException ex) {
            System.out.println("Erro ao excluir produto: " + ex.getMessage());
            return false;
        }
    }
}
