package dao;

import beans.Categoria;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;   // comando SQL com parâmetros (?), evita erro de aspas e SQL injection
import java.sql.ResultSet;           // resultado de um SELECT (linhas e colunas)
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO (Data Access Object) = classe que fala com o banco.
 * Aqui ficam TODOS os comandos SQL da tabela Categorias. As telas (view) nunca escrevem SQL:
 * elas só chamam os métodos desta classe.
 */
public class CategoriaDAO {
    private Conexao conexao;
    private Connection conn;

    // Construtor: toda vez que faz "new CategoriaDAO()" já abre a conexão com o banco.
    public CategoriaDAO() {
        this.conexao = new Conexao();             // cria o objeto de conexão
        this.conn = this.conexao.getConexao();    // abre a conexão e guarda em conn
    }

    // LISTAR TODAS -> usado para encher o combo de categorias e a tabela
    public List<Categoria> getCategorias(){
        String sql = "SELECT * FROM Categorias";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);   // prepara o SQL
            ResultSet rs = stmt.executeQuery();                    // executa o SELECT
            List<Categoria> lista = new ArrayList<>();             // lista que vai guardar o resultado
            while (rs.next()) {                                    // rs.next() anda linha por linha até acabar
                Categoria c = new Categoria();
                c.setId(rs.getInt("id_categoria"));                // pega a coluna pelo NOME e coloca no objeto
                c.setNome(rs.getString("nome"));
                lista.add(c);                                      // adiciona o objeto na lista
            }
            return lista;
        } catch (SQLException ex) {
            System.out.println("Erro ao consultar categorias: " + ex.getMessage());
            return null;   // as telas conferem "if (lista == null)"
        }
    }

    // FILTRAR POR NOME -> usado na tela de tabela (LIKE com % = "contém o texto")
    public List<Categoria> getCategoriasNome(String nome){
        String sql = "SELECT * FROM Categorias WHERE nome LIKE ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stmt.setString(1, "%" + nome + "%");                   // 1 = primeiro "?" do SQL; % antes e depois = contém
            ResultSet rs = stmt.executeQuery();
            List<Categoria> lista = new ArrayList<>();
            while (rs.next()) {
                Categoria c = new Categoria();
                c.setId(rs.getInt("id_categoria"));
                c.setNome(rs.getString("nome"));
                lista.add(c);
            }
            return lista;
        } catch (SQLException ex) {
            System.out.println("Erro ao consultar categorias: " + ex.getMessage());
            return null;
        }
    }

    // CONSULTAR POR ID -> usado no botão Consultar (devolve UMA categoria ou null se não existir)
    public Categoria getCategoria(int id){
        String sql = "SELECT * FROM Categorias WHERE id_categoria = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stmt.setInt(1, id);                                    // coloca o id no "?"
            ResultSet rs = stmt.executeQuery();
            if (rs.first()) {                                      // rs.first() = true se achou a primeira linha
                Categoria c = new Categoria();
                c.setId(rs.getInt("id_categoria"));
                c.setNome(rs.getString("nome"));
                return c;
            }
            return null;                                           // não achou ninguém com esse id
        } catch (SQLException ex) {
            System.out.println("Erro ao consultar categoria: " + ex.getMessage());
            return null;
        }
    }

    // INSERT -> devolve true se salvou, false se deu erro (a tela usa isso para escolher a mensagem)
    public boolean inserir(Categoria c){
        String sql = "INSERT INTO Categorias (nome) VALUES (?)";   // o id é AUTO_INCREMENT, não precisa informar
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, c.getNome());
            stmt.execute();                                        // execute() é usado em INSERT/UPDATE/DELETE
            return true;
        } catch (SQLException ex) {
            System.out.println("Erro ao inserir categoria: " + ex.getMessage());
            return false;
        }
    }

    // UPDATE -> o WHERE id_categoria = ? é OBRIGATÓRIO, senão altera todas as linhas
    public boolean editar(Categoria c){
        String sql = "UPDATE Categorias SET nome = ? WHERE id_categoria = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, c.getNome());                        // 1º "?" = nome
            stmt.setInt(2, c.getId());                             // 2º "?" = id (a ordem segue o SQL)
            stmt.execute();
            return true;
        } catch (SQLException ex) {
            System.out.println("Erro ao atualizar categoria: " + ex.getMessage());
            return false;
        }
    }

    // DELETE -> falha (false) se a categoria ainda tem produtos, por causa da chave estrangeira
    public boolean excluir(int id){
        String sql = "DELETE FROM Categorias WHERE id_categoria = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.execute();
            return true;
        } catch (SQLException ex) {
            System.out.println("Erro ao excluir categoria: " + ex.getMessage());
            return false;
        }
    }
}
