package principal;

import view.MenuPrincipal;

/**
 * Classe de entrada alternativa: abre o menu do sistema.
 * (O projeto já está configurado para iniciar direto pelo view.MenuPrincipal.)
 */
public class Principal {
    public static void main(String[] args) {
        new MenuPrincipal().setVisible(true);   // cria o menu e mostra na tela
    }
}
