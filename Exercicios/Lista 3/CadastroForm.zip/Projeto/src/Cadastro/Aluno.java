/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Cadastro;

/**
 *
 * @author laboratorio
 */
public class Aluno {
    String nome;
    String dataNascimento;
    String sexo;
    String matricula;
    String curso;
    String cpf;
    String rua;
    String numero;
    String bairro;
    String cidade;
    String cep;
    String estado;
    String telefone;

    public Aluno(String nome, String dataNascimento, String sexo,
                 String matricula, String curso, String cpf,
                 String rua, String numero, String bairro,
                 String cidade, String cep, String estado,
                 String telefone) {

        this.nome = nome;
        this.dataNascimento = dataNascimento;
        this.sexo = sexo;
        this.matricula = matricula;
        this.curso = curso;
        this.cpf = cpf;
        this.rua = rua;
        this.numero = numero;
        this.bairro = bairro;
        this.cidade = cidade;
        this.cep = cep;
        this.estado = estado;
        this.telefone = telefone;
    }

    @Override
    public String toString() {
        return nome + ";" +
               dataNascimento + ";" +
               sexo + ";" +
               matricula + ";" +
               curso + ";" +
               cpf + ";" +
               rua + ";" +
               numero + ";" +
               bairro + ";" +
               cidade + ";" +
               cep + ";" +
               estado + ";" +
               telefone;
    }
}
