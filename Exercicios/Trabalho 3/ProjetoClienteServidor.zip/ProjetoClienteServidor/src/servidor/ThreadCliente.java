package servidor;

import beans.Pessoa;
import dao.PessoaDAO;
import java.io.IOException;
import java.io.ObjectInputFilter;
import java.io.ObjectInputStream;    // lê objetos que chegam pelo Socket
import java.io.ObjectOutputStream;   // escreve objetos para o Socket
import java.net.Socket;

/**
 * THREAD QUE ATENDE UM CLIENTE.
 * Cada conexão aceita pelo Servidor ganha uma ThreadCliente própria (extends Thread).
 * O que o método run() faz (é o que roda dentro da Thread):
 *   1) lê o objeto Pessoa enviado pelo cliente
 *   2) tenta inserir no banco (PessoaDAO)
 *   3) devolve "sucesso..." ou "erro: motivo"
 * Todo o código está dentro de try/catch/finally para que NENHUM problema derrube o servidor.
 */
public class ThreadCliente extends Thread {

    private Socket socket;   // conexão com o cliente que esta Thread atende

    public ThreadCliente(Socket socket) {
        this.socket = socket;
    }

    // run() é o "main" da Thread: roda quando o Servidor chama t.start()
    @Override
    public void run() {
        PessoaDAO dao = null;   // fica fora do try para o finally conseguir fechar a conexão com o banco
        try {
            // Se o cliente conectar e ficar mudo, a Thread desiste depois de 30 s (senão ficaria presa para sempre)
            socket.setSoTimeout(30000);

            // ORDEM IMPORTANTE: cria primeiro o ObjectOutputStream e dá flush(), depois o ObjectInputStream.
            // (os dois lados fazem igual; se os dois começarem lendo, ficam esperando um ao outro = travamento)
            ObjectOutputStream saida = new ObjectOutputStream(socket.getOutputStream());
            saida.flush();
            ObjectInputStream entrada = new ObjectInputStream(socket.getInputStream());

            // Segurança: só aceita objetos da classe beans.Pessoa (e Strings). Qualquer outra coisa é recusada.
            entrada.setObjectInputFilter(ObjectInputFilter.Config.createFilter("beans.Pessoa;java.lang.*;!*"));

            String resposta;   // texto que será devolvido ao cliente
            try {
                Object recebido = entrada.readObject();     // 1) lê o objeto enviado pelo cliente (fica esperando até chegar)
                if (!(recebido instanceof Pessoa)) {        // instanceof confere o tipo (também recusa null)
                    throw new Exception("o objeto recebido não é uma Pessoa");
                }
                Pessoa p = (Pessoa) recebido;               // agora o cast é seguro

                dao = new PessoaDAO();                      // abre a conexão com o banco (uma por Thread)
                dao.inserir(p);                             // 2) insere (lança SQLException se der erro)
                resposta = "sucesso: pessoa '" + p.getNome() + "' cadastrada!";
                System.out.println("[" + getName() + "] cadastrou: " + p.getNome());
            } catch (Exception e) {
                // QUALQUER erro (banco fora do ar, nome vazio, objeto inválido...) vira a mensagem "erro: motivo"
                resposta = "erro: " + e.getMessage();
                System.out.println("[" + getName() + "] " + resposta);
            }

            saida.writeObject(resposta);   // 3) devolve a resposta para o cliente
            saida.flush();                 // flush() garante que os bytes saíram agora
        } catch (Exception e) {
            // problema de comunicação (cliente caiu, timeout...). Só registra; só ESTA Thread termina.
            System.out.println("[" + getName() + "] falha na comunicação: " + e.getMessage());
        } finally {
            // finally roda sempre (com erro ou sem): libera o que foi aberto
            if (dao != null) {
                dao.fechar();              // fecha a conexão com o banco
            }
            try {
                socket.close();            // fecha a conexão com o cliente
            } catch (IOException e) {
                System.out.println("Erro ao fechar o socket: " + e.getMessage());
            }
        }
    }
}
