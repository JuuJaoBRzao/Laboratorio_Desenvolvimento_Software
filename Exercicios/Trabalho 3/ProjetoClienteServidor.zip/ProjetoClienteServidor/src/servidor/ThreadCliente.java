package servidor;

import beans.Pessoa;
import dao.PessoaDAO;
import java.io.IOException;
import java.io.ObjectInputFilter;
import java.io.ObjectInputStream;    
import java.io.ObjectOutputStream;   
import java.net.Socket;

/**

 */
public class ThreadCliente extends Thread {

    private Socket socket;   

    public ThreadCliente(Socket socket) {
        this.socket = socket;
    }

 
    @Override
    public void run() {
        PessoaDAO dao = null;   
        try {
            socket.setSoTimeout(30000);


            ObjectOutputStream saida = new ObjectOutputStream(socket.getOutputStream());
            saida.flush();
            ObjectInputStream entrada = new ObjectInputStream(socket.getInputStream());

        
            entrada.setObjectInputFilter(ObjectInputFilter.Config.createFilter("beans.Pessoa;java.lang.*;!*"));

            String resposta;  
            try {
                Object recebido = entrada.readObject();    
                if (!(recebido instanceof Pessoa)) {       
                    throw new Exception("o objeto recebido não é uma Pessoa");
                }
                Pessoa p = (Pessoa) recebido;             

                dao = new PessoaDAO();                     
                dao.inserir(p);                            
                resposta = "sucesso: pessoa '" + p.getNome() + "' cadastrada!";
                System.out.println("[" + getName() + "] cadastrou: " + p.getNome());
            } catch (Exception e) {

                resposta = "erro: " + e.getMessage();
                System.out.println("[" + getName() + "] " + resposta);
            }

            saida.writeObject(resposta);  
            saida.flush();                
        } catch (Exception e) {
   
            System.out.println("[" + getName() + "] falha na comunicação: " + e.getMessage());
        } finally {
            
            if (dao != null) {
                dao.fechar();            
            }
            try {
                socket.close();           
            } catch (IOException e) {
                System.out.println("Erro ao fechar o socket: " + e.getMessage());
            }
        }
    }
}
