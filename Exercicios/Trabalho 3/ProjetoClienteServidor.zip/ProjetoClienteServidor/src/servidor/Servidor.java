package servidor;

import java.io.IOException;
import java.net.ServerSocket;   
import java.net.Socket;         

/**

 */
public class Servidor {

   
    public static final int PORTA = 12345;

    public static void main(String[] args) {
 
        try (ServerSocket servidor = new ServerSocket(PORTA)) {    
            System.out.println("Servidor aguardando conexões na porta " + PORTA + "...");

            while (true) {                                           
                try {
                    Socket cliente = servidor.accept();               
                    System.out.println("Cliente conectado: " + cliente.getInetAddress().getHostAddress());

                    ThreadCliente t = new ThreadCliente(cliente);     
                    t.start();                                        
                } catch (IOException e) {
                    System.out.println("Erro ao aceitar conexão: " + e.getMessage());
                }
            }
        } catch (IOException e) {
            System.out.println("Não foi possível abrir a porta " + PORTA + ": " + e.getMessage());
        }
    }
}
