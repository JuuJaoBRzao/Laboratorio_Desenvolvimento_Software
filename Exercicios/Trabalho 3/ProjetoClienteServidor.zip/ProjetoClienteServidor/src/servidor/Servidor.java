package servidor;

import java.io.IOException;
import java.net.ServerSocket;   // "tomada" do servidor: fica esperando conexões numa porta
import java.net.Socket;         // conexão com UM cliente

/**
 * PROGRAMA SERVIDOR (tem o seu próprio main). Rodar este ANTES de abrir o cliente.
 * Papel: ficar esperando conexões e, para cada cliente que conectar, criar uma Thread (ThreadCliente) para atendê-lo.
 * Por isso vários clientes conseguem cadastrar ao mesmo tempo: o laço principal volta a esperar logo em seguida.
 */
public class Servidor {

    // Porta onde o servidor escuta. O cliente precisa usar o MESMO número.
    public static final int PORTA = 12345;

    public static void main(String[] args) {
        // try-with-resources: fecha o ServerSocket sozinho se o programa terminar
        try (ServerSocket servidor = new ServerSocket(PORTA)) {      // abre a porta (erro se ela já estiver em uso)
            System.out.println("Servidor aguardando conexões na porta " + PORTA + "...");

            while (true) {                                            // laço infinito: o servidor nunca para de atender
                try {
                    Socket cliente = servidor.accept();               // BLOQUEIA até um cliente conectar e devolve o Socket dele
                    System.out.println("Cliente conectado: " + cliente.getInetAddress().getHostAddress());

                    ThreadCliente t = new ThreadCliente(cliente);     // cria a Thread que vai atender ESTE cliente
                    t.start();                                        // start() inicia a Thread (chamar run() direto NÃO cria Thread nova)
                } catch (IOException e) {
                    // erro ao aceitar um cliente: só registra e volta a esperar, o servidor não cai
                    System.out.println("Erro ao aceitar conexão: " + e.getMessage());
                }
            }
        } catch (IOException e) {
            System.out.println("Não foi possível abrir a porta " + PORTA + ": " + e.getMessage());
        }
    }
}
