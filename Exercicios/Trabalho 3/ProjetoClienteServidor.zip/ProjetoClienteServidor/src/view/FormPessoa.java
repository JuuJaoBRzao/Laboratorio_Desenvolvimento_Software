/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package view;

import beans.Pessoa;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import javax.swing.JOptionPane;  

/**

 */
public class FormPessoa extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(FormPessoa.class.getName());
    private static final String HOST = "localhost";
    private static final int PORTA = 12345;

    /**
     * Creates new form FormPessoa
     */
    public FormPessoa() {
        initComponents();
    }

  
    private void limparFormulario() {
        txtNome.setText("");
        btnGrpSexo.clearSelection();      
        cmbIdioma.setSelectedIndex(0);     
        txtNome.requestFocus();           
    }

    /**
 
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        // ---- 1) cria cada componente da tela (os que você arrasta da Palette no modo Design) ----
        btnGrpSexo = new javax.swing.ButtonGroup();   // ButtonGroup = faz só UM radio button ficar marcado por vez
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtNome = new javax.swing.JTextField();
        rdoMasculino = new javax.swing.JRadioButton();
        rdoFeminino = new javax.swing.JRadioButton();
        cmbIdioma = new javax.swing.JComboBox<>();
        btnCadastrar = new javax.swing.JButton();

        // ---- 2) propriedades da janela ----
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE); // fechar a janela encerra o programa cliente
        setTitle("Cadastro de Pessoa (Cliente)");

        // ---- 3) propriedades de cada componente ----
        jLabel1.setText("Nome:");

        jLabel2.setText("Sexo");

        jLabel3.setText("Idioma");

        btnGrpSexo.add(rdoMasculino);               // coloca o radio dentro do grupo
        rdoMasculino.setText("Masculino");

        btnGrpSexo.add(rdoFeminino);
        rdoFeminino.setText("Feminino");

        // itens do combo (o primeiro, em branco, significa "nenhum idioma escolhido")
        cmbIdioma.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " ", "Português", "Inglês", "Alemão", "Francês" }));

        btnCadastrar.setText("Cadastrar");
        btnCadastrar.addActionListener(new java.awt.event.ActionListener() { // liga o CLIQUE do botão ao método abaixo
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadastrarActionPerformed(evt);
            }
        });

        // ---- 4) posição dos componentes na janela (GroupLayout, gerado pelo editor visual) ----
        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(64, 64, 64)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(rdoMasculino)
                        .addGap(33, 33, 33)
                        .addComponent(rdoFeminino))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(cmbIdioma, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(62, 62, 62)
                        .addComponent(btnCadastrar)))
                .addContainerGap(64, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(rdoMasculino)
                    .addComponent(rdoFeminino))
                .addGap(15, 15, 15)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(cmbIdioma, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCadastrar))
                .addContainerGap(30, Short.MAX_VALUE))
        );

        pack(); // ajusta o tamanho da janela ao conteúdo
        setLocationRelativeTo(null); // centraliza a janela na tela
    }// </editor-fold>//GEN-END:initComponents


    private void btnCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadastrarActionPerformed

        Pessoa p = new Pessoa();
        p.setNome(txtNome.getText());
        if (rdoMasculino.isSelected()) {
            p.setSexo("M");
        } else if (rdoFeminino.isSelected()) {
            p.setSexo("F");
        }                                                  
        p.setIdioma(cmbIdioma.getSelectedItem() + "");     

        String resposta;   
       
        try (Socket socket = new Socket()) {
            socket.connect(new InetSocketAddress(HOST, PORTA), 3000);
            socket.setSoTimeout(10000);   

            ObjectOutputStream saida = new ObjectOutputStream(socket.getOutputStream());
            saida.flush();
            ObjectInputStream entrada = new ObjectInputStream(socket.getInputStream());


            saida.writeObject(p);
            saida.flush();


            resposta = (String) entrada.readObject();
        } catch (Exception e) {

            resposta = "erro: não foi possível falar com o servidor (" + e.getMessage() + ")";
        }


        if (resposta.startsWith("sucesso")) {
            JOptionPane.showMessageDialog(this, resposta, "Resposta do servidor", JOptionPane.INFORMATION_MESSAGE);
            limparFormulario();   
        } else {
            JOptionPane.showMessageDialog(this, resposta, "Resposta do servidor", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnCadastrarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new FormPessoa().setVisible(true)); 
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup btnGrpSexo;
    private javax.swing.JButton btnCadastrar;
    private javax.swing.JComboBox<String> cmbIdioma;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JRadioButton rdoFeminino;
    private javax.swing.JRadioButton rdoMasculino;
    private javax.swing.JTextField txtNome;
    // End of variables declaration//GEN-END:variables
}
