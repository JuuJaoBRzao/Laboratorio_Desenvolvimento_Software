package beans;

import java.io.Serializable;   // permite transformar o objeto em bytes para enviar pelo Socket

/**
 * BEAN Pessoa. É a MESMA classe usada pelo cliente e pelo servidor (os dois programas estão neste projeto).
 * Para enviar um objeto pela rede com ObjectOutputStream a classe precisa implements Serializable.
 * Atributos: nome, sexo e idioma (o id existe só no banco, quem gera é o AUTO_INCREMENT).
 */
public class Pessoa implements Serializable {

    // Número de versão da classe. Cliente e servidor precisam ter a MESMA versão, senão dá InvalidClassException.
    private static final long serialVersionUID = 1L;

    private String nome;
    private String sexo;     // "M" ou "F"
    private String idioma;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getIdioma() {
        return idioma;
    }

    public void setIdioma(String idioma) {
        this.idioma = idioma;
    }
}
