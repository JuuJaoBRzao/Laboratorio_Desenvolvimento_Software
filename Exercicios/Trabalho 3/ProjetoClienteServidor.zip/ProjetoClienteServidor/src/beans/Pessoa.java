package beans;

import java.io.Serializable;

/*
 */
public class Pessoa implements Serializable {


    private static final long serialVersionUID = 1L;

    private String nome;
    private String sexo;     
    private String idioma;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getIdioma() {
        return idioma;
    }

    public void setIdioma(String idioma) {
        this.idioma = idioma;
    }
}
