package dao;

import beans.Pessoa;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 */
public class PessoaDAO {

    private Conexao conexao;
    private Connection conn;


    public PessoaDAO() {
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }


    public void inserir(Pessoa p) throws SQLException {
        if (conn == null) {
            throw new SQLException("não foi possível conectar ao banco de dados");
        }

        String nome = p.getNome();
        if (nome != null && nome.trim().isEmpty()) {
            nome = null;
        }

        String sql = "INSERT INTO pessoa (nome, sexo, idioma) VALUES (?, ?, ?)";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, nome);                 
        stmt.setString(2, p.getSexo());         
        stmt.setString(3, p.getIdioma());     
        stmt.execute();                          
        stmt.close();
    }

    public void fechar() {
        try {
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            System.out.println("Erro ao fechar conexão: " + e.getMessage());
        }
    }
}
