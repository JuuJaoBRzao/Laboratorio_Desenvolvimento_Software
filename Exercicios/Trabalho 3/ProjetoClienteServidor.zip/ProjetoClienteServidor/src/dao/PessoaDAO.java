package dao;

import beans.Pessoa;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * DAO da tabela pessoa (usado pelo SERVIDOR).
 * Diferença para os DAOs das outras aulas: aqui o inserir() NÃO engole a exceção, ele a "lança" (throws SQLException).
 * Assim quem chamou (a Thread do servidor) consegue ler o motivo do erro e mandar para o cliente.
 */
public class PessoaDAO {

    private Conexao conexao;
    private Connection conn;

    // Construtor: cada "new PessoaDAO()" abre uma conexão própria (cada Thread do servidor tem a sua, sem misturar)
    public PessoaDAO() {
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }

    // INSERT. Se der qualquer problema lança SQLException, e a mensagem vira o "erro: motivo" que o cliente recebe.
    public void inserir(Pessoa p) throws SQLException {
        // Banco fora do ar: getConexao() devolveu null. Sem este if daria NullPointerException (mensagem sem sentido).
        if (conn == null) {
            throw new SQLException("não foi possível conectar ao banco de dados");
        }

        String nome = p.getNome();
        // Nome vazio ("" ou só espaços) vira NULL: o MySQL aceitaria "" mesmo com NOT NULL, mas NÃO aceita NULL.
        // Assim o banco recusa e dá para testar a mensagem de erro de "campo obrigatório vazio".
        if (nome != null && nome.trim().isEmpty()) {
            nome = null;
        }

        String sql = "INSERT INTO pessoa (nome, sexo, idioma) VALUES (?, ?, ?)";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, nome);                 // 1º "?"
        stmt.setString(2, p.getSexo());          // 2º "?"
        stmt.setString(3, p.getIdioma());        // 3º "?"
        stmt.execute();                          // executa o INSERT (se violar NOT NULL lança SQLException aqui)
        stmt.close();
    }

    // Fecha a conexão. O servidor chama no "finally" de cada Thread, senão as conexões se acumulam e o MySQL recusa novas.
    public void fechar() {
        try {
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            System.out.println("Erro ao fechar conexão: " + e.getMessage());
        }
    }
}
