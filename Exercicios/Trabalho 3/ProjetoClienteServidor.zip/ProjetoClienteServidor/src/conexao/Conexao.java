package conexao;

import java.sql.Connection;      // representa a conexão aberta com o banco
import java.sql.DriverManager;   // classe que cria a conexão a partir da URL do banco
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * CLASSE DE CONEXÃO COM O BANCO. Só o SERVIDOR usa (o cliente nunca fala direto com o banco).
 * Pré-requisito: o driver mysql-connector-j-8.1.0.jar precisa estar em Libraries do projeto.
 */
public class Conexao {

    public Connection getConexao(){
        Connection conn;
        try {
            // Formato da URL: jdbc:mysql://servidor:porta/NOME_DO_BANCO   |   usuário   |   senha
            // >>> Troque a senha ("1234") pela do seu MySQL, se for outra.
            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/clienteservidor?useTimezone=true&serverTimezone=UTC",
                    "root","1234");
            System.out.println("Conexão efetuada!");   // aparece no console do servidor
            return conn;                               // devolve a conexão pronta para o DAO usar
        } catch (Exception e) {
            // cai aqui se o MySQL estiver desligado, o banco não existir ou a senha estiver errada
            System.out.println("Erro ao conectar no BD: "+e.getMessage());
            Logger.getLogger(Conexao.class.getName()).log(Level.SEVERE, null, e);
        }
        return  null;   // sem conexão devolve null (o DAO confere isso)
    }
}
