/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trabalho1;

import java.util.Vector;

/**
 *
 * @author laboratorio
 */
public class Aluno {
    public String nome;
    public String dataNasc;
    public char sexo;
    public int matricula;
    public String curso;
    public String cpf;
    public String rua;
    public String numero;
    public String bairro;
    public String cidade;
    public String cep;
    public String estado;
    public String telefone;

    public Aluno(String nome, String dataNasc, char sexo, int matricula, String curso, String cpf, String rua, String numero, String bairro, String cidade, String cep, String estado, String telefone) {
        this.nome = nome;
        this.dataNasc = dataNasc;
        this.sexo = sexo;
        this.matricula = matricula;
        this.curso = curso;
        this.cpf = cpf;
        this.rua = rua;
        this.numero = numero;
        this.bairro = bairro;
        this.cidade = cidade;
        this.cep = cep;
        this.estado = estado;
        this.telefone = telefone;
    }

    public Object[] obterDados(){
        return new Object[] {nome, dataNasc, sexo, matricula, curso, cpf,
                              rua, numero, bairro, cidade, cep, estado, telefone};
    }
}
