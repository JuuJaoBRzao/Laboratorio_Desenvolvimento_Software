/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trabalho1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author laboratorio
 */
public class Arquivo {
    private FileWriter arqW;
    private BufferedWriter escritor;
    
    private FileReader arqR;
    private BufferedReader leitor;
    
    private List<Aluno> listaAlunos;
    public String nomeArquivo;

    public Arquivo (String nomeArquivo){
        this.nomeArquivo = nomeArquivo;
        listaAlunos = new ArrayList<>();
    }
    
    public List<Aluno> leArquivo(){
        listaAlunos.clear();
        
        try {
            arqR = new FileReader (nomeArquivo + ".txt");
            leitor = new BufferedReader(arqR);
            
            String linha;

            while ((linha = leitor.readLine()) != null) {
                String[] campos = linha.split(";");

                String nome = campos[0];
                String dataNascimento = campos[1];
                char sexo = campos[2].charAt(0);
                int matricula = Integer.parseInt(campos[3]);
                String curso = campos[4];
                String cpf = campos[5];
                String rua = campos[6];
                String numero = campos[7];
                String bairro = campos[8];
                String cidade = campos[9];
                String cep = campos[10];
                String estado = campos[11];
                String telefone = campos[12];

                Aluno a = new Aluno(nome, dataNascimento, sexo, matricula, curso, cpf,
                                    rua, numero, bairro, cidade, cep, estado, telefone);

                listaAlunos.add(a);
            }

            leitor.close();
            arqR.close();

        } catch (FileNotFoundException e) {
            // Arquivo ainda não existe.
            // Começa com a lista vazia.
            System.out.println("Arquivo ainda não existe.");

        } catch (IOException e) {
            e.printStackTrace();
        }

        return listaAlunos;
    }

    public List<Aluno> getListaAlunos() {
        return listaAlunos;
    }

    // Grava TODA a lista no arquivo
    public void gravaArquivo() {
        try {
            arqW = new FileWriter(nomeArquivo + ".txt", false);
            escritor = new BufferedWriter(arqW);

            for (Aluno a : listaAlunos) {
                escritor.write(
                    a.nome + ";" +
                    a.dataNasc + ";" +
                    a.sexo + ";" +
                    a.matricula + ";" +
                    a.curso + ";" +
                    a.cpf + ";" +
                    a.rua + ";" +
                    a.numero + ";" +
                    a.bairro + ";" +
                    a.cidade + ";" +
                    a.cep + ";" +
                    a.estado + ";" +
                    a.telefone
                );

                escritor.newLine();
            }

            escritor.close();
            arqW.close();

            System.out.println("Lista salva no arquivo!");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
