/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.cadastroespecies;

/**
 *
 * @author Usuário
 */
public class CadastroEspecies {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
