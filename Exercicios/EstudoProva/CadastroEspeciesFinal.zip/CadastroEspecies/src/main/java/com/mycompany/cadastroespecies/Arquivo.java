/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cadastroespecies;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Usuário
 */
public class Arquivo {
     private FileWriter arqW;
    private BufferedWriter escritor;
    
    private FileReader arqR;
    private BufferedReader leitor;
    
    private List<Especies> listaEspecies;
    
    public String nomeArquivo;
    
     public Arquivo(String nomeArquivo){
        this.nomeArquivo = nomeArquivo;
        listaEspecies = new ArrayList<>();
    }
    
    public List<Especies> leArquivo() throws IOException{
        listaEspecies.clear();
        
        try {
            arqR = new FileReader(nomeArquivo + ".txt");
            leitor = new BufferedReader(arqR);
            
            String linha;
            
            while ((linha = leitor.readLine()) != null) {
                String[] campos = linha.split(";");
                
                String nome = campos[0];
                String apelido = campos[1];
                float peso = Float.parseFloat(campos[2]);
                float altura = Float.parseFloat(campos[3]);
                String grupo = campos [4];
                char sexo = campos[5].charAt(0);
                
                Especies e = new Especies(nome, apelido, peso, altura, grupo, sexo);
                
                listaEspecies.add(e);
            }
            
            leitor.close();
            arqR.close();
        } catch (FileNotFoundException e) {
            //Arquivo ainda não existe
            // Começa com a linha vazia
            System.out.println("Arquivo ainda não existe");
        } catch (IOException e){
            e.printStackTrace();
        }
        return listaEspecies;
    }
    
    public List<Especies> getListaPessoas(){
        return listaEspecies;
    }
    
    //grava TODA a lista noi arquivo
    public void gravaArquivo(){
        
        try{
            arqW = new FileWriter(nomeArquivo + ".txt", false);
            escritor = new BufferedWriter(arqW);
            
            for (Especies e: listaEspecies) {
                escritor.write(
                        e.nome + ";" +
                        e.apelido + ";" +
                        e.peso + ";" +
                        e.altura + ";" +
                        e.grupo + ";" +
                        e.sexo
                );
                
                escritor.newLine();
            }
            
            escritor.close();
            arqW.close();
            
            System.out.println("Lista salva no arquivo");
        } catch (IOException e){
            e.printStackTrace();
        }
    }
}
