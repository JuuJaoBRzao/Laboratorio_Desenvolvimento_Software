/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cadastroespecies;

/**
 *
 * @author Usuário
 */
public class Especies {
    public String nome;
    public String apelido;
    public float peso;
    public float altura;
    public String grupo;
    public char sexo;

    public Especies(String nome, String apelido, float peso, float altura, String grupo, char sexo) {
        this.nome = nome;
        this.apelido = apelido;
        this.peso = peso;
        this.altura = altura;
        this.grupo = grupo;
        this.sexo = sexo;
    }

    @Override
    public String toString() {
        return "Especies{" + "nome=" + nome + ", apelido=" + apelido + ", peso=" + peso + ", altura=" + altura + ", grupo=" + grupo + ", sexo=" + sexo + '}';
    }
    
    public Object[] obterDados(){
        return new Object[]{
            nome, apelido, peso, altura, grupo, sexo
        };
    }
}

