/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cadastroprodutos;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Usuário
 */
public class Arquivo {
     private FileWriter arqW;
    private BufferedWriter escritor;
    
    private FileReader arqR;
    private BufferedReader leitor;
    
    private List<Produtos> listaProdutos;
    
    public String nomeArquivo;
    
     public Arquivo(String nomeArquivo){
        this.nomeArquivo = nomeArquivo;
        listaProdutos = new ArrayList<>();
    }
    
    public List<Produtos> leArquivo() throws IOException{
        listaProdutos.clear();
        
        try {
            arqR = new FileReader(nomeArquivo + ".txt");
            leitor = new BufferedReader(arqR);
            
            String linha;
            
            while ((linha = leitor.readLine()) != null) {
                String[] campos = linha.split(";");
                
                String nome = campos[0];
                int codigo = Integer.parseInt(campos[1]);
                float preco = Float.parseFloat(campos[2]);
                int quantidade = Integer.parseInt(campos[3]);
                String medida = campos [4];
                String fornecedor = campos[5];
                char origem = campos[6].charAt(0);
                
                Produtos p = new Produtos(nome, codigo, preco, quantidade, medida, fornecedor, origem);
                
                listaProdutos.add(p);
            }
            
            leitor.close();
            arqR.close();
        } catch (FileNotFoundException e) {
            //Arquivo ainda não existe
            // Começa com a linha vazia
            System.out.println("Arquivo ainda não existe");
        } catch (IOException e){
            e.printStackTrace();
        }
        return listaProdutos;
    }
    
    public List<Produtos> getListaPessoas(){
        return listaProdutos;
    }
    
    //grava TODA a lista noi arquivo
    public void gravaArquivo(){
        
        try{
            arqW = new FileWriter(nomeArquivo + ".txt", false);
            escritor = new BufferedWriter(arqW);
            
            for (Produtos p: listaProdutos) {
                escritor.write(
                        p.nome + ";" +
                        p.codigo + ";" +
                        p.preco + ";" +
                        p.quantidade + ";" +
                        p.medida + ";" +
                        p.fornecedor + ";" +
                        p.origem
                );
                
                escritor.newLine();
            }
            
            escritor.close();
            arqW.close();
            
            System.out.println("Lista salva no arquivo");
        } catch (IOException e){
            e.printStackTrace();
        }
    }
}

