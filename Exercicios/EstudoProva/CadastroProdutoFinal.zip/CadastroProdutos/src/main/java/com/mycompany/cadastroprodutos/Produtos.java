/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cadastroprodutos;

/**
 *
 * @author Usuário
 */
public class Produtos {
    public String nome;
    public int codigo;
    public float preco;
    public int quantidade;
    public String medida;
    public String fornecedor;
    public char origem;

    public Produtos(String nome, int codigo, float preco, int quantidade, String medida, String fornecedor, char origem) {
        this.nome = nome;
        this.codigo = codigo;
        this.preco = preco;
        this.quantidade = quantidade;
        this.medida = medida;
        this.fornecedor = fornecedor;
        this.origem = origem;
    }

    @Override
    public String toString() {
        return "Produtos{" + "nome=" + nome + ", codigo=" + codigo + ", preco=" + preco + ", quantidade=" + quantidade + ", medida=" + medida + ", fornecedor=" + fornecedor + ", origem=" + origem + '}';
    }
    
     public Object[] obterDados(){
        return new Object[]{
            nome, codigo, preco, quantidade, medida, fornecedor, origem
        };
    }
}
