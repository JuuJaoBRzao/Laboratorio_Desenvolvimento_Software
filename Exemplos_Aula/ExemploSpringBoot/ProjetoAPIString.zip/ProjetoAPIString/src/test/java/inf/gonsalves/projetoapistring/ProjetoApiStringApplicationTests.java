package inf.gonsalves.projetoapistring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoApiStringApplicationTests {

    @Test
    void contextLoads() {
    }

}
