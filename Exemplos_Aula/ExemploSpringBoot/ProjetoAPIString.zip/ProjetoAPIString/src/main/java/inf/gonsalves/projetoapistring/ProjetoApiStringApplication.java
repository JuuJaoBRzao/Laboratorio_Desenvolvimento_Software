package inf.gonsalves.projetoapistring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoApiStringApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProjetoApiStringApplication.class, args);
    }

}
