package dao;

import beans.Professor;
import java.sql.Connection;
import conexao.Conexao;
import java.sql.*;

public class ProfessorDAO {
    private Conexao conexao;
    private Connection conn;

    public ProfessorDAO() {
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }
    
    public boolean inserir (Professor obj){
        String sql = "INSERT INTO professores (nome, idade, disciplina) VALUES (?, ?, ?);";
        
        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1,obj.getNome());
            stmt.setInt(2,obj.getIdade());
            stmt.setString(3,obj.getDisciplina());
            
            stmt.execute();
            return true;
        } catch (SQLException ex){
            System.out.println("Erro ao inserir professor: "+ex.getMessage());
            return false;
        }
    }
}
