package dao;

import beans.Aluno;
import java.sql.Connection;
import conexao.Conexao;
import java.sql.*;

public class AlunoDAO {
    private Conexao conexao;
    private Connection conn;

    public AlunoDAO() {
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }
    
    public boolean inserir (Aluno obj){
        String sql = "INSERT INTO alunos (nome, idade, curso) VALUES (?, ?, ?);";
        
        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1,obj.getNome());
            stmt.setInt(2,obj.getIdade());
            stmt.setString(3,obj.getCurso());
            
            stmt.execute();
            return true;
        } catch (SQLException ex){
            System.out.println("Erro ao inserir aluno: "+ex.getMessage());
            return false;
        }
    }
}
