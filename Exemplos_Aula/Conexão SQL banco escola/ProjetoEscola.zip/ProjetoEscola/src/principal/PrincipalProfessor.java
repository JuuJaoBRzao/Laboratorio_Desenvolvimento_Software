package principal;

import Interface.InterfaceProfessor;

public class PrincipalProfessor {
    public static void main(String[] args) {
        new InterfaceProfessor().setVisible(true);
    }
}
