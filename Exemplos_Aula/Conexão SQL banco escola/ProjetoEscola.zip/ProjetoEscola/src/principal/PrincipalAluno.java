package principal;

import Interface.InterfaceAluno;

public class PrincipalAluno {
    public static void main(String[] args) {
        new InterfaceAluno().setVisible(true);
    }
}
